import EmployeeProfile from "./components/EmployeeProfile";

export default function App() {
  return (
    <div className="min-h-screen">
      <EmployeeProfile />
    </div>
  );
}