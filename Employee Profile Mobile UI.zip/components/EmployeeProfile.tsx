"use client";

import { motion } from "framer-motion";
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  Building, 
  Badge, 
  IdCard,
  Users,
  AlertCircle
} from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Separator } from "./ui/separator";

interface EmployeeData {
  name: string;
  employeeId: string;
  designation: string;
  department: string;
  passportNo: string;
  workPermitNo: string;
  nationality: string;
  contact: string;
  email: string;
  address: string;
  dateOfJoin: string;
  emergencyContact: string;
}

const employeeData: EmployeeData = {
  name: "ADHUHAM LAYAAL QASIM",
  employeeId: "5016",
  designation: "HR EXECUTIVE",
  department: "HR Department",
  passportNo: "",
  workPermitNo: "",
  nationality: "",
  contact: "9969252",
  email: "work.adhuham@gmail.com",
  address: "H. Masriq (3rd floor), k. Male, maldives",
  dateOfJoin: "2024-09-05",
  emergencyContact: "Wife (7559001)"
};

const EmployeeProfile = () => {
  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    }
  };

  const InfoRow = ({ icon: Icon, label, value, iconColor = "text-blue-600" }: {
    icon: any;
    label: string;
    value: string;
    iconColor?: string;
  }) => (
    <motion.div 
      variants={itemVariants}
      className="flex items-start gap-3 p-3 bg-gray-50/50 rounded-lg hover:bg-gray-100/50 transition-colors"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <Icon className={`w-4 h-4 mt-0.5 ${iconColor}`} />
      <div className="flex-1 min-w-0">
        <p className="text-xs text-gray-600 mb-1">{label}</p>
        <p className="text-sm break-words">{value || "Not Available"}</p>
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-md mx-auto"
      >
        {/* Main Profile Card */}
        <Card className="overflow-hidden shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
          <CardContent className="p-0">
            {/* Header Section */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 text-center">
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="mb-4"
              >
                <Avatar className="w-20 h-20 mx-auto border-4 border-white/30 shadow-lg">
                  <AvatarFallback className="bg-white/20 text-white text-lg">
                    {employeeData.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
              </motion.div>
              
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <h1 className="mb-1">{employeeData.name}</h1>
                <p className="text-blue-100 text-sm mb-1">{employeeData.designation}</p>
                <p className="text-blue-200 text-xs">Employee ID: {employeeData.employeeId}</p>
              </motion.div>
            </div>

            {/* Employee Information */}
            <div className="p-6 space-y-6">
              {/* Work Information */}
              <motion.div variants={itemVariants}>
                <div className="flex items-center gap-2 mb-4">
                  <Building className="w-5 h-5 text-blue-600" />
                  <h3 className="text-blue-600">Work Information</h3>
                </div>
                <div className="space-y-3">
                  <InfoRow 
                    icon={Building} 
                    label="Department" 
                    value={employeeData.department}
                    iconColor="text-blue-600"
                  />
                  <InfoRow 
                    icon={Calendar} 
                    label="Date of Joining" 
                    value={employeeData.dateOfJoin}
                    iconColor="text-green-600"
                  />
                </div>
              </motion.div>

              <Separator className="my-6" />

              {/* Contact Information */}
              <motion.div variants={itemVariants}>
                <div className="flex items-center gap-2 mb-4">
                  <Phone className="w-5 h-5 text-green-600" />
                  <h3 className="text-green-600">Contact Information</h3>
                </div>
                <div className="space-y-3">
                  <InfoRow 
                    icon={Phone} 
                    label="Phone Number" 
                    value={employeeData.contact}
                    iconColor="text-green-600"
                  />
                  <InfoRow 
                    icon={Mail} 
                    label="Email Address" 
                    value={employeeData.email}
                    iconColor="text-blue-600"
                  />
                  <InfoRow 
                    icon={MapPin} 
                    label="Address" 
                    value={employeeData.address}
                    iconColor="text-purple-600"
                  />
                </div>
              </motion.div>

              <Separator className="my-6" />

              {/* Personal Information */}
              <motion.div variants={itemVariants}>
                <div className="flex items-center gap-2 mb-4">
                  <User className="w-5 h-5 text-purple-600" />
                  <h3 className="text-purple-600">Personal Information</h3>
                </div>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <InfoRow 
                      icon={IdCard} 
                      label="Passport No" 
                      value={employeeData.passportNo}
                      iconColor="text-gray-600"
                    />
                    <InfoRow 
                      icon={Badge} 
                      label="Work Permit" 
                      value={employeeData.workPermitNo}
                      iconColor="text-gray-600"
                    />
                  </div>
                  <InfoRow 
                    icon={Users} 
                    label="Nationality" 
                    value={employeeData.nationality}
                    iconColor="text-orange-600"
                  />
                  <InfoRow 
                    icon={AlertCircle} 
                    label="Emergency Contact" 
                    value={employeeData.emergencyContact}
                    iconColor="text-red-600"
                  />
                </div>
              </motion.div>

              <Separator className="my-6" />

              {/* Action Buttons */}
              <motion.div 
                variants={itemVariants}
                className="grid grid-cols-2 gap-4"
              >
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg">
                    Edit Profile
                  </Button>
                </motion.div>
                
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button variant="outline" className="w-full border-blue-200 hover:bg-blue-50 shadow-sm">
                    Download PDF
                  </Button>
                </motion.div>
              </motion.div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default EmployeeProfile;