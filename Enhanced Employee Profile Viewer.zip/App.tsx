import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Skeleton } from './components/ui/skeleton';
import { Alert, AlertDescription } from './components/ui/alert';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { Separator } from './components/ui/separator';
import { User, Mail, Phone, MapPin, Calendar, Users, IdCard, Building, Flag } from 'lucide-react';

interface Employee {
  emp_no: string;
  name: string;
  designation: string;
  department: string;
  contact_number: string;
  email: string;
  persentaddress: string;
  date_of_join: string;
  emergency_contact_name: string;
  emergency_contact_number: string;
  passport_no?: string;
  work_permit_no?: string;
  nationality?: string;
}

const InfoRow = ({ icon: Icon, label, value }: { icon: any, label: string, value: string | undefined }) => {
  if (!value) return null;
  
  return (
    <div className="flex items-start gap-3 py-2">
      <Icon className="w-4 h-4 mt-1 text-muted-foreground flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="break-words">{value}</p>
      </div>
    </div>
  );
};

export default function App() {
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const emp_no = new URLSearchParams(window.location.search).get('emp_no');

  useEffect(() => {
    if (!emp_no) {
      setError('No employee number provided in URL parameters.');
      setLoading(false);
      return;
    }

    // Mock API call since we can't make real external requests
    // In a real application, you would uncomment the axios call below
    
    // Simulating API response with mock data
    setTimeout(() => {
      try {
        // Mock successful response
        const mockEmployee: Employee = {
          emp_no: emp_no,
          name: "John Doe",
          designation: "Software Engineer",
          department: "Information Technology",
          contact_number: "+960 123-4567",
          email: "john.doe@company.com",
          persentaddress: "Male', Maldives",
          date_of_join: "2022-01-15",
          emergency_contact_name: "Jane Doe",
          emergency_contact_number: "+960 987-6543",
          passport_no: "A1234567",
          work_permit_no: "WP123456",
          nationality: "Maldivian"
        };
        
        setEmployee(mockEmployee);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch employee data.');
        setLoading(false);
      }
    }, 1000);

    /* Real API call - uncomment when ready to use
    axios
      .get(`https://api.rccmaldives.com/ess/employees/index.php?emp_no=${emp_no}`)
      .then((res) => {
        if (res.data.status === 'success') {
          setEmployee(res.data.data);
        } else {
          setError(res.data.message || 'Employee not found');
        }
        setLoading(false);
      })
      .catch(() => {
        setError('Failed to fetch employee data.');
        setLoading(false);
      });
    */
  }, [emp_no]);

  if (error) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <div className="w-full max-w-md">
          <Alert variant="destructive">
            <AlertDescription className="text-center">
              🚫 {error}
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader className="text-center">
              <Skeleton className="w-24 h-24 rounded-full mx-auto mb-4" />
              <Skeleton className="h-8 w-48 mx-auto mb-2" />
              <Skeleton className="h-4 w-32 mx-auto" />
            </CardHeader>
            <CardContent className="space-y-4">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="flex items-center gap-3">
                  <Skeleton className="w-4 h-4" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-3 w-24" />
                    <Skeleton className="h-4 w-full" />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <div className="text-center">
          <h3>No employee data available</h3>
        </div>
      </div>
    );
  }

  const profileImageUrl = `https://api.rccmaldives.com/ess/document/index.php?emp_no=${employee.emp_no}`;
  const initials = employee.name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader className="text-center pb-6">
            <Avatar className="w-24 h-24 mx-auto mb-4">
              <AvatarImage src={profileImageUrl} alt={employee.name} />
              <AvatarFallback className="text-lg">
                {initials}
              </AvatarFallback>
            </Avatar>
            <h1 className="text-2xl mb-2">{employee.name}</h1>
            <div className="flex flex-wrap justify-center gap-2 mb-2">
              <Badge variant="secondary">{employee.designation}</Badge>
              <Badge variant="outline">{employee.department}</Badge>
            </div>
            <p className="text-muted-foreground">Employee ID: {employee.emp_no}</p>
          </CardHeader>
          
          <CardContent className="space-y-1">
            <div className="grid gap-1">
              <InfoRow icon={Phone} label="Contact Number" value={employee.contact_number} />
              <InfoRow icon={Mail} label="Email Address" value={employee.email} />
              <InfoRow icon={MapPin} label="Address" value={employee.persentaddress} />
              <InfoRow icon={Calendar} label="Date of Joining" value={employee.date_of_join} />
              
              <Separator className="my-4" />
              
              <InfoRow icon={IdCard} label="Passport Number" value={employee.passport_no} />
              <InfoRow icon={IdCard} label="Work Permit Number" value={employee.work_permit_no} />
              <InfoRow icon={Flag} label="Nationality" value={employee.nationality} />
              
              <Separator className="my-4" />
              
              <div className="space-y-1">
                <div className="flex items-center gap-3 py-2">
                  <Users className="w-4 h-4 mt-1 text-muted-foreground flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground">Emergency Contact</p>
                    <p>{employee.emergency_contact_name}</p>
                    <p className="text-sm text-muted-foreground">{employee.emergency_contact_number}</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}